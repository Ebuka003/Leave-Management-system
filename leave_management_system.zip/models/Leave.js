
const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema({
    type: String,
    startDate: Date,
    endDate: Date,
    reason: String,
    status: { type: String, default: 'Pending' },
});

const Leave = mongoose.model('Leave', leaveSchema);
module.exports = Leave;
