
const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema({
    type: String,
    startDate: Date,
    endDate: Date,
    reason: String,
    status: { type: String, default: 'Pending' },
});

const employeeSchema = new mongoose.Schema({
    name: String,
    id: { type: String, unique: true },
    password: String,
    leaveBalance: {
        Annual: { type: Number, default: 20 },
        Sick: { type: Number, default: 10 },
        Casual: { type: Number, default: 5 },
    },
    leaveRequests: [leaveSchema],
});

const Employee = mongoose.model('Employee', employeeSchema);
module.exports = Employee;
