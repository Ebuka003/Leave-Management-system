
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');
const flash = require('connect-flash');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const Employee = require('./models/Employee');

const app = express();
const PORT = process.env.PORT || 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/leave_management', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({ secret: 'secret', resave: false, saveUninitialized: true }));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

// Passport config
passport.use(new LocalStrategy((username, password, done) => {
    Employee.findOne({ id: username }, (err, employee) => {
        if (err) return done(err);
        if (!employee) return done(null, false, { message: 'Incorrect username.' });
        if (employee.password !== password) return done(null, false, { message: 'Incorrect password.' });
        return done(null, employee);
    });
}));

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser((id, done) => {
    Employee.findById(id, (err, user) => {
        done(err, user);
    });
});

// Routes
app.use('/leave', require('./routes/leave'));
app.use('/auth', require('./routes/auth'));

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
